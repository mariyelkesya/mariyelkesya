#include <cs50.h>
#include <stdio.h>

{
    int n;
    do
    {
        n = get_int("Width: ");
    }
    while (n < 1);


int main(void)


    for (int i = 0; i < 4; i++)
    {
        printf("?");
    }
    printf("\n");
}