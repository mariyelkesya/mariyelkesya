#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string name = get_string("Why're u gae!\n");
    printf("Halp meh, %s\n, name");
}
